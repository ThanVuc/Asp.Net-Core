Alter table GiangVien
Add LoaiGV nvarchar(20)