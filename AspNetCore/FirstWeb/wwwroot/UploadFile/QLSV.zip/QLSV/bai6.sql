Alter table Diem
Add Constraint fk_sv_change
Foreign Key (MaSV) References SinhVien(MaSV)
On Delete Cascade

delete from sinhvien where MaSV='SV05'