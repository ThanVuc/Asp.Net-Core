﻿Set NoCount On
Insert into MonHoc(MaMH,TenMH,SoTC) values ('CSDL','Cơ Sở Dữ Liệu',3)
Insert into MonHoc(MaMH,TenMH,SoTC) values ('CTDL','Cấu trúc dữ liệu',3)
Insert into MonHoc(MaMH,TenMH,SoTC) values ('TIDC','Tin Đại Cương',3)
Insert into MonHoc(MaMH,TenMH,SoTC) values ('TIUD','Tin Ứng Dụng',3)
Insert into MonHoc(MaMH,TenMH,SoTC) values ('TORR','Toán Rời Rạc',3)

