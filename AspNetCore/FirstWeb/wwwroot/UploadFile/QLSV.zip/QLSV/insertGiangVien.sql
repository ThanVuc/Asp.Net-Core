﻿Set NoCount On
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('CNTCNP01','Lê Anh',1,'1970-05-12','120 Lê Lợi Đà Nẵng')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('CNTCNP02','Trần Thị Cẩm Nhung',0,'1979-02-15','49 Lê Hồng Phong')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('CNTKTM01','Lê Tuấn Anh',1,'1985-05-12','50 Trần Phú Quảng Nam')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('CNTKTM02','Phan Anh Hùng',1,'1990-02-28','125 Trần Phú Quảng Bình')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('CNTHTT01','Trần Thị Hương Trà',1,'1970-05-12','125 Trần Phú Quảng Bình')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('CNTHTT02','Trần Thị Hương Trà',1,'1970-05-12','125 Trần Phú Quảng Bình')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('DVTDTD01','Mạc Cẩm Trâm',0,'1980-07-12','20 Lê Độ Đà Nẵng')
insert into GiangVien(MaGV,TenGV,GT,NgaySinh,DiaChi) values ('DVTDTD02','Phan Hồng Anh',0,'1980-10-12','25 Phan Châu Trinh Đà Nẵng')