﻿Set NoCount On
Insert into Lop(MaLop,TenLop,CVHT) Values ('K19CDQ','Cao Đẳng Quản Trị Mạng','Lê Văn Tám')
Insert into Lop(MaLop,TenLop,CVHT) Values ('K19CDT','Cao Đẳng Hệ Thống Thông Tin','Quách Tuấn Ngọc')
Insert into Lop(MaLop,TenLop,CVHT) Values ('K19HTT','Hệ Thống Thông Tin','Ông Văn Thông')
Insert into Lop(MaLop,TenLop,CVHT) Values ('K19QTM','Quản Trị Mạng','Trần Mai Khuê')
Insert into Lop(MaLop,TenLop,CVHT) Values ('K19TPM','Công Nghệ Phầm Mềm','Kiều Mai Lý')
Insert into Lop(MaLop,TenLop,CVHT) Values ('K19CDM','Cao Đẳng Công Nghệ Phần Mềm','Phạm Văn Ất')
