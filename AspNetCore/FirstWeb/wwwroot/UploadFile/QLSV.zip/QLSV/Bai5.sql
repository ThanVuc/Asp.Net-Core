Alter table Diem
Add Constraint add_Diem1 Check (0<=DiemLan1 and DiemLan1<=10)
Alter table Diem
Add Constraint add_Diem2 Check (0<=DiemLan2 and DiemLan2<=10)
Alter table MonHoc
Add Constraint add_tc Check (1<=SoTC and SoTC<=4)
Alter table Lop
Add Constraint add_lop Unique(TenLop)
Alter table SinhVien
Add Constraint add_tuoi Check (Year(GetDate()) - Year(NgaySinh) >= 16 and Year(GetDate()) - Year(NgaySinh) <= 80)