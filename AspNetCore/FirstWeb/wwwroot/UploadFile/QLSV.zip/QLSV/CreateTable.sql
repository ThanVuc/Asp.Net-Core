Create table Lop(
MaLop nvarchar(10) primary key,
TenLop nvarchar(50),
CVhT nvarchar(50) not null
)

Create table SinhVien(
MaSV nvarchar(10) primary key,
TenSV nvarchar(50) not null unique,
HoLot nvarchar(50),
Phai bit,
NgaySinh datetime,
DiaChi ntext,
DienThoai nvarchar(10),
MaLop nvarchar(10) not null
Constraint fk_MaLop
Foreign key (MaLop)
References Lop(MaLop)
)

Create table MonHoc(
MaMH nvarchar(10) primary key,
TenMH nvarchar(50) not null unique,
SoTC int
)

Create table Diem(
MaSV nvarchar(10),
MaMH nvarchar(10),
DiemLan1 float,
DiemLan2 float,
Constraint pk_ Primary Key (MaSV,MaMH),
Constraint fk_MaSV Foreign Key (MaSV) References SinhVien(MaSV),
Constraint fk_MaMH Foreign Key (MaMh) References MonHoc(MaMH)
)

Create table GiangVien(
MaGV nvarchar(10) primary key,
TenGV nvarchar(50) not null,
GT bit,
NgaySinh DateTime,
DiaChi nvarchar(100),
MaKhoa nvarchar(10)
)

Create table GiangDay(
MaGV nvarchar(10),
MaLop nvarchar(10),
MaMH nvarchar(10),
TGBD Datetime,
TGKT Datetime
Constraint fk_MaGV
Foreign Key(MaGV)
References GiangVien(MaGV),
Constraint fk_MaMH1
Foreign Key(MaMH)
References MonHoc(MaMH),
Constraint fk_MaLop1
Foreign Key(MaLop)
References Lop(MaLop)
)