Alter table GiangDay
Drop column TGBD

Alter table GiangDay
Drop column TGKT